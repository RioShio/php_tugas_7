        <!-- Footer -->
        <footer class="footer">
            <p>&copy; 2026 DayNight Admin. Designed by <a href="https://www.templatemo.com" target="_blank" rel="nofollow">TemplateMo</a></p>
        </footer>
    </div>

    <script src="templatemo-daynight-script.js"></script>
</body>
</html>